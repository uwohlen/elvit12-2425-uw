For å kjøre mine programmer trengs
... for oppgave 8
... for oppgave 9


I oppgave 3 var spørsmålet uklart. ... kan tolkes som ... 
Jeg valgte å tolke det slik at ...





